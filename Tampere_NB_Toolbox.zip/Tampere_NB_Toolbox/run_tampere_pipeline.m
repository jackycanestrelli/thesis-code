%% ============================================================================
%  run_tampere_pipeline.m   --   TAMPERE NETWORK-BURST TOOLBOX (V1)
%  ----------------------------------------------------------------------------
%  ONE script that does the whole job on a MEA spike file:
%     STEP 1  load the raw spike data
%     STEP 2  filter out inactive electrodes/wells        (firing-rate filter)
%     STEP 3  detect network bursts with the Tampere V1 detector
%     STEP 4  draw & save a raster + firing-rate figure for every well
%
%  HOW TO USE (no programming needed):
%     1. Open this file in MATLAB.
%     2. Edit ONLY the "SETTINGS" block just below.
%     3. Press the green "Run" button (or F5).
%
%  Results are written into the folder set by RESULTS_ROOT.
%  ============================================================================

clear; clc;

%% ===================== SETTINGS (edit these) ================================

% Full path to ONE raw spike file (e.g. DD1C.mat, DD5A.mat, TUBA.mat, C10902.mat).
% The file must contain a nested struct  .(plate).(DIV).(well) = table(Time, Channel).
DATA_FILE = fullfile(pwd, 'example_input', 'DD1C.mat');

% Where to save the results (network bursts + figures). Created automatically.
RESULTS_ROOT = fullfile(pwd, 'results');

% Detector parameter set: 1..4. Set 2 is the reference / recommended one.
PARAM_SET = 2;

% Firing-rate filter on/off (recommended: true).
APPLY_FR_FILTER = true;

% Time window shown in the raster figures, in seconds, as [t0 t1].
% Use [] to show the whole recording (0-600 s). A short window (e.g. [60 120])
% makes individual bursts much easier to see.
RASTER_WINDOW = [60 120];

% How many wells to plot. Use inf to plot every well, or a small number
% (e.g. 6) to just get a quick look.
MAX_WELLS_TO_PLOT = inf;

%% ===================== (you should not need to edit below) ==================

% Make all toolbox functions visible to MATLAB.
thisDir = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(thisDir, 'functions')));

% ----- STEP 1: load raw spike data -----------------------------------------
if ~exist(DATA_FILE, 'file')
    error(['Data file not found:\n  %s\n' ...
        'Put a raw spike .mat file in the example_input folder ' ...
        'and update DATA_FILE above.'], DATA_FILE);
end
fprintf('STEP 1  Loading %s ...\n', DATA_FILE);
S       = load(DATA_FILE);
fn      = fieldnames(S);
[~, base] = fileparts(DATA_FILE);
if isfield(S, base)
    cellLineName = base;           % variable named like the file (e.g. DD1C)
else
    cellLineName = fn{1};          % otherwise take the first variable
end
CellData = S.(cellLineName);
fprintf('        Loaded cell line "%s".\n', cellLineName);

% ----- STEP 2: firing-rate filter (pre-processing) -------------------------
if APPLY_FR_FILTER
    fprintf('STEP 2  Filtering inactive electrodes/wells ...\n');
    CellData = filter_electrodes_by_FR(CellData);
else
    fprintf('STEP 2  Firing-rate filter skipped (APPLY_FR_FILTER = false).\n');
end

% ----- STEP 3: Tampere V1 network-burst detection --------------------------
fprintf('STEP 3  Detecting network bursts (Tampere V1, parameter set %d) ...\n', PARAM_SET);
Params = get_tampere_params(PARAM_SET);
NB_Tampere = run_NBdetection_tampere(CellData, Params, @DetectNetworkBurstsNeuro);

saveDir = fullfile(RESULTS_ROOT, 'network_bursts');
if ~exist(saveDir, 'dir'), mkdir(saveDir); end
outMat = fullfile(saveDir, sprintf('NB_Tampere_%s.mat', cellLineName));
save(outMat, 'NB_Tampere', '-v7.3');
fprintf('        Network bursts saved (.mat): %s\n', outMat);

% Also export a spreadsheet-friendly CSV (one row per network burst).
outCsv = fullfile(saveDir, sprintf('NB_Tampere_%s.csv', cellLineName));
export_NB_csv(NB_Tampere, cellLineName, outCsv);

% ----- STEP 4: raster + firing-rate figures --------------------------------
fprintf('STEP 4  Drawing raster + firing-rate figures ...\n');
figRoot = fullfile(RESULTS_ROOT, 'raster_firingrate', cellLineName);
nPlotted = 0;

plates = fieldnames(CellData);
for pi = 1:numel(plates)
    plate = plates{pi};
    divs  = fieldnames(CellData.(plate));
    for di = 1:numel(divs)
        DIV   = divs{di};
        wells = fieldnames(CellData.(plate).(DIV));
        for wi = 1:numel(wells)
            if nPlotted >= MAX_WELLS_TO_PLOT, break; end
            well = wells{wi};
            spikeTable = CellData.(plate).(DIV).(well);
            if isempty(spikeTable) || height(spikeTable) == 0, continue; end

            NB = struct('starts', [], 'ends', []);
            if isfield(NB_Tampere, plate) && isfield(NB_Tampere.(plate), DIV) && ...
               isfield(NB_Tampere.(plate).(DIV), well)
                NB = NB_Tampere.(plate).(DIV).(well);
            end

            outDir  = fullfile(figRoot, DIV);
            outFile = fullfile(outDir, sprintf('%s_%s_%s_%s_raster.png', ...
                cellLineName, plate, DIV, well));
            ttl = sprintf('%s | %s | %s | %s', cellLineName, plate, DIV, well);

            plot_raster_firingrate(spikeTable, NB, ...
                'Title', ttl, 'TimeWindow', RASTER_WINDOW, ...
                'SavePath', outFile, 'Visible', 'off');
            nPlotted = nPlotted + 1;
        end
    end
end

fprintf('\nDONE. %d raster figure(s) written under:\n  %s\n', nPlotted, figRoot);
fprintf('Network-burst results:\n  %s  (MATLAB)\n  %s  (Excel/CSV)\n', outMat, outCsv);
