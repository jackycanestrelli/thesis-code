EXAMPLE OUTPUT
==============

When you run run_tampere_pipeline.m, the toolbox creates a "results" folder
next to the script. This example_output folder shows what those results look
like, so you know what to expect.

You can copy here, as reference examples, the files the pipeline produces:

1) NETWORK BURSTS  (folder: results/network_bursts/)
   - NB_Tampere_DD1C.mat   : the detected network bursts, for MATLAB.
   - NB_Tampere_DD1C.csv   : the SAME results as a spreadsheet (open in Excel).
                             One row per network burst, columns:
                               CellLine, Plate, DIV, Well, NB_index,
                               Start_s, End_s, Duration_s, Num_fragments,
                               Is_fragmented, Num_active_channels

2) RASTER + FIRING-RATE FIGURES  (folder: results/raster_firingrate/DD1C/<DIV>/)
   - DD1C_<plate>_<DIV>_<well>_raster.png
     Each figure shows, for one well:
        * black raster (one row per electrode, one tick per spike),
        * the smoothed firing rate on top (blue line, right axis),
        * light-blue shaded bands = detected network bursts,
        * magenta dots = fragment (sub-burst) peaks.

HOW TO POPULATE THIS FOLDER
---------------------------
Run the pipeline once, then copy the NB_Tampere_DD1C.csv / .mat and one or two
_raster.png files from the results folder into here as worked examples.
