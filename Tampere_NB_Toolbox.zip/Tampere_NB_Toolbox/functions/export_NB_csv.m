function T = export_NB_csv(NB_Tampere, cellLineName, csvPath)
% export_NB_csv  Write the detected network bursts to a tidy CSV file.
%
%   Produces ONE row per network burst, with the columns below, so the results
%   can be opened directly in Excel / LibreOffice by anyone.
%
% INPUT
%   NB_Tampere   : nested struct .(plate).(DIV).(well) returned by
%                  run_NBdetection_tampere.
%   cellLineName : name of the cell line (e.g. 'DD1C'), written in every row.
%   csvPath      : full path of the .csv file to create (folders are created).
%
% OUTPUT
%   T : the same table that is written to disk (also returned for convenience).
%
% CSV COLUMNS
%   CellLine            cell-line name
%   Plate               MEA plate id
%   DIV                 day in vitro
%   Well                well id
%   NB_index            network-burst number within the well (1,2,3,...)
%   Start_s             burst start time [s]
%   End_s               burst end time [s]
%   Duration_s          End_s - Start_s [s]
%   Num_fragments       number of sub-bursts (fragments) inside the burst
%   Is_fragmented       1 if the burst has >= 2 fragments, else 0
%   Num_active_channels number of electrodes taking part in the burst

CellLine = {}; Plate = {}; DIVc = {}; Well = {};
NB_index = []; Start_s = []; End_s = []; Duration_s = [];
Num_fragments = []; Is_fragmented = []; Num_active_channels = [];

plates = fieldnames(NB_Tampere);
for pi = 1:numel(plates)
    plate = plates{pi};
    divs  = fieldnames(NB_Tampere.(plate));
    for di = 1:numel(divs)
        DIV   = divs{di};
        wells = fieldnames(NB_Tampere.(plate).(DIV));
        for wi = 1:numel(wells)
            well = wells{wi};
            NB   = NB_Tampere.(plate).(DIV).(well);

            if isempty(NB) || ~isfield(NB, 'starts') || isempty(NB.starts)
                continue    % this well has no network bursts
            end

            n = numel(NB.starts);
            for k = 1:n
                CellLine{end+1,1} = cellLineName; %#ok<AGROW>
                Plate{end+1,1}    = plate;        %#ok<AGROW>
                DIVc{end+1,1}     = DIV;          %#ok<AGROW>
                Well{end+1,1}     = well;         %#ok<AGROW>
                NB_index(end+1,1) = k;            %#ok<AGROW>
                Start_s(end+1,1)  = NB.starts(k); %#ok<AGROW>
                End_s(end+1,1)    = NB.ends(k);   %#ok<AGROW>
                Duration_s(end+1,1) = NB.ends(k) - NB.starts(k); %#ok<AGROW>

                nf = 0;
                if isfield(NB, 'num_fragments') && numel(NB.num_fragments) >= k
                    nf = NB.num_fragments(k);
                end
                Num_fragments(end+1,1) = nf;          %#ok<AGROW>
                Is_fragmented(end+1,1) = double(nf >= 2); %#ok<AGROW>

                nch = NaN;
                if isfield(NB, 'CHANNELSFIN') && numel(NB.CHANNELSFIN) >= k ...
                        && ~isempty(NB.CHANNELSFIN{k})
                    nch = height(NB.CHANNELSFIN{k});
                end
                Num_active_channels(end+1,1) = nch;   %#ok<AGROW>
            end
        end
    end
end

T = table(CellLine, Plate, DIVc, Well, NB_index, Start_s, End_s, ...
    Duration_s, Num_fragments, Is_fragmented, Num_active_channels, ...
    'VariableNames', {'CellLine','Plate','DIV','Well','NB_index', ...
    'Start_s','End_s','Duration_s','Num_fragments','Is_fragmented', ...
    'Num_active_channels'});

outDir = fileparts(csvPath);
if ~isempty(outDir) && ~exist(outDir, 'dir'), mkdir(outDir); end
writetable(T, csvPath);
fprintf('        Network bursts (CSV) saved: %s  (%d bursts)\n', csvPath, height(T));
end
