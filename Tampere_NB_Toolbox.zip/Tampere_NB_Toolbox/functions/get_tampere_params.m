function Params = get_tampere_params(setNum)
% get_tampere_params  Return the parameters for the Tampere V1 network-burst
%   detector (DetectNetworkBurstsNeuro).
%
%   These are the same values used in the thesis (Table 3.3). Four parameter
%   sets are available; SET 2 IS THE REFERENCE / RECOMMENDED one and is used by
%   default. You normally do NOT need to change anything here.
%
% INPUT
%   setNum : (optional) parameter set 1..4. Default = 2 (recommended).
%
% OUTPUT
%   Params : parameter struct passed to DetectNetworkBurstsNeuro.
%
% WHAT THE MAIN PARAMETERS MEAN (plain language):
%   MinCount               minimum number of network bursts required in a well
%   MinDuration            minimum duration of a network burst (seconds)
%   MinChannels            minimum number of electrodes taking part in a burst
%   MinChannelContribution how strongly an electrode must fire to "count"
%   timeBin                bin width used to build the firing-rate trace (25 ms)
%   sigma / kernelsize     width of the Gaussian smoothing of the firing rate

if nargin < 1 || isempty(setNum), setNum = 2; end
assert(ismember(setNum,1:4), 'setNum must be 1, 2, 3 or 4.');

timeBin = 25e-3;   % seconds (fixed)

% Columns = Set 1..4  (Set 2 = reference)
BinsPerDec  = [20   22   25   30];
Span        = [3    3    2    2];
sigma_bins  = [3    3    6    10];    % 75/150/250 ms over a 25 ms bin
kernelsize  = [6    19   37   61];   % Set 1 keeps the historical kernel
MinCount    = [8    10   12   15];
MinDuration = [0.35 0.40 0.50 0.60];
MergingFrac = [0.20 0.20 0.30 0.40];
MinChannels = [3    4    5    6];
MinDomChan  = [3    4    5    6];
MinChanContr= [0.20 0.25 0.30 0.40];

s = setNum;

Params = struct();
Params.LogISINHist.Smoother   = 'lowess';
Params.LogISINHist.BinsPerDec = BinsPerDec(s);
Params.LogISINHist.Span       = Span(s);
Params.LogISINHist.N          = 20;              % ISI-N order (fixed)
Params.MinCount               = MinCount(s);
Params.MinDuration            = MinDuration(s);  % s
Params.MergingType            = 'Adaptive';      % fixed
Params.MergingFracOrThres     = MergingFrac(s);
Params.MinChannels            = MinChannels(s);
Params.MinDomChannels         = MinDomChan(s);
Params.MinChannelContribution = MinChanContr(s);
Params.timeBin                = timeBin;
Params.kernelsize             = kernelsize(s);
Params.sigma                  = sigma_bins(s);
end
