function plot_raster_firingrate(spikeTable, NB, varargin)
% plot_raster_firingrate  Raster + firing-rate figure for ONE well (Tampere V1).
%
%   Draws, for a single well:
%     - a RASTER: one row per electrode, a vertical tick for every spike;
%     - the smoothed FIRING RATE trace on top (right y-axis);
%     - shaded blue bands where the Tampere V1 detector found NETWORK BURSTS;
%     - magenta dots on the fragment (sub-burst) peaks inside network bursts.
%
% USAGE
%   plot_raster_firingrate(spikeTable, NB)
%   plot_raster_firingrate(spikeTable, NB, 'Name', Value, ...)
%
% INPUT
%   spikeTable : table for one well with columns  Time [s]  and  Channel
%                (exactly the format stored in the raw .mat files).
%   NB         : the Tampere network-burst struct for the SAME well, as returned
%                by run_NBdetection_tampere / DetectNetworkBurstsNeuro. It must
%                contain the firing-rate trace fields .spikeTimes and
%                .spikeratesmooth (the runner always adds them).
%
% OPTIONAL NAME-VALUE ARGUMENTS
%   'Title'      : title string for the figure. Default ''.
%   'TimeWindow' : [t0 t1] seconds to display. Default = whole recording.
%   'SavePath'   : full path of a .png to save (folders are created). If empty,
%                  the figure is only shown, not saved. Default ''.
%   'Visible'    : 'on' (default) or 'off' (useful for batch saving).
%
% OUTPUT
%   none (a figure is drawn and, if SavePath is given, saved as PNG).

% ----- parse options -----
p = inputParser;
p.addParameter('Title', '', @(x)ischar(x)||isstring(x));
p.addParameter('TimeWindow', [], @(x)isempty(x)||(isnumeric(x)&&numel(x)==2));
p.addParameter('SavePath', '', @(x)ischar(x)||isstring(x));
p.addParameter('Visible', 'on', @(x)ischar(x)||isstring(x));
p.parse(varargin{:});
opt = p.Results;

if isempty(spikeTable) || height(spikeTable) == 0
    warning('plot_raster_firingrate: empty spike table, nothing to plot.');
    return
end

Time    = spikeTable.Time;
Channel = spikeTable.Channel;

% ----- time window -----
if isempty(opt.TimeWindow)
    t0 = min(Time);
    t1 = max(Time);
else
    t0 = opt.TimeWindow(1);
    t1 = opt.TimeWindow(2);
end
mask    = Time >= t0 & Time <= t1;
Time    = Time(mask);
Channel = Channel(mask);

if isempty(Time)
    warning('plot_raster_firingrate: no spikes in the requested time window.');
    return
end

% ----- electrodes sorted numerically when possible -----
electrodes  = unique(Channel, 'stable');
electrodes  = local_sortElectrodes(electrodes);
nElectrodes = numel(electrodes);

% ----- figure -----
fig = figure('Color', 'w', 'Visible', char(opt.Visible), ...
    'Position', [80 80 1100 520], 'NumberTitle', 'off');
ax = axes(fig); hold(ax, 'on');

% ---------- LEFT axis: raster ----------
yyaxis(ax, 'left');
for e = 1:nElectrodes
    et = Time(Channel == electrodes(e));
    if iscell(electrodes)
        et = Time(strcmp(Channel, electrodes{e}));
    end
    plot(ax, et, e*ones(numel(et),1), '|', 'MarkerSize', 8, ...
        'Color', [0 0 0], 'HandleVisibility', 'off');
end
ylim(ax, [0 nElectrodes+1]);
ylabel(ax, 'Electrodes');
ax.YColor = [0 0 0];

% ---------- shaded network-burst windows ----------
if ~isempty(NB) && isfield(NB, 'starts') && ~isempty(NB.starts)
    for i = 1:numel(NB.starts)
        x1 = max(t0, NB.starts(i));
        x2 = min(t1, NB.ends(i));
        if x2 <= x1, continue; end
        patch(ax, [x1 x2 x2 x1], ...
            [0.5 0.5 nElectrodes+0.5 nElectrodes+0.5], ...
            [0.35 0.65 1.00], 'FaceAlpha', 0.10, ...
            'EdgeColor', [0.10 0.30 0.80], 'LineWidth', 1.2, ...
            'HandleVisibility', 'off');
    end
end

% ---------- RIGHT axis: smoothed firing rate ----------
yyaxis(ax, 'right');
ax.YColor = [0.15 0.35 0.75];
ylabel(ax, 'Firing rate (Hz)');

hasFR = ~isempty(NB) && isfield(NB, 'spikeTimes') && ...
        isfield(NB, 'spikeratesmooth') && ~isempty(NB.spikeratesmooth);
if hasFR
    tFR = NB.spikeTimes(:);
    yFR = NB.spikeratesmooth(:);
    inWin = tFR >= t0 & tFR <= t1;
    plot(ax, tFR(inWin), yFR(inWin), '-', 'Color', [0.15 0.35 0.75], ...
        'LineWidth', 1.8, 'DisplayName', 'Firing rate');

    % fragment (sub-burst) peaks inside network bursts
    if isfield(NB, 'fragmentPeakTimes') && ~isempty(NB.fragmentPeakTimes)
        fp = [NB.fragmentPeakTimes{:}];
        fp = fp(fp >= t0 & fp <= t1);
        if ~isempty(fp)
            yp = interp1(tFR, yFR, fp, 'linear', 'extrap');
            scatter(ax, fp, yp, 26, 'm', 'filled', 'DisplayName', 'Fragment peaks');
        end
    end
    legend(ax, 'Location', 'northeast', 'Box', 'off');
end

xlim(ax, [t0 t1]);
xlabel(ax, 'Time (s)');
grid(ax, 'on'); box(ax, 'on');
if ~isempty(char(opt.Title))
    title(ax, char(opt.Title), 'Interpreter', 'none');
end

drawnow;

% ---------- save ----------
if ~isempty(char(opt.SavePath))
    outDir = fileparts(char(opt.SavePath));
    if ~isempty(outDir) && ~exist(outDir, 'dir'), mkdir(outDir); end
    exportgraphics(fig, char(opt.SavePath), 'Resolution', 300);
    fprintf('  Saved raster: %s\n', char(opt.SavePath));
    if strcmpi(opt.Visible, 'off'), close(fig); end
end
end

% ===== helper: sort electrode labels numerically when possible =====
function es = local_sortElectrodes(electrodes)
if iscell(electrodes) || isstring(electrodes)
    ec = cellstr(electrodes(:));
    nums = str2double(ec);
    if all(~isnan(nums))
        [~, idx] = sort(nums);
        es = ec(idx);
    else
        es = sort(ec);
    end
else
    es = sort(electrodes(:));
end
end
