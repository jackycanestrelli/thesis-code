# Tampere Network-Burst Toolbox (V1)

A small, self-contained MATLAB toolbox that takes raw MEA spike data and, in one
run, **filters it, detects network bursts (Tampere V1 method), and draws a
raster + firing-rate figure for every well**. It also exports the detected
network bursts as an Excel-friendly **CSV**.

It is written to be used by people who do **not** program: you only edit a few
clearly-marked settings and press *Run*.

---

## 1. What it does, step by step

1. **Loads** one raw spike file (e.g. `DD1C.mat`).
2. **Filters** out electrodes and wells that barely fire (firing-rate filter),
   so that noise does not affect the analysis.
3. **Detects network bursts** — moments when many electrodes fire together —
   using the Tampere V1 detector (the log-ISI-N method).
4. **Saves the results** as:
   - a MATLAB file (`.mat`),
   - a spreadsheet (`.csv`, one row per network burst),
   - one **raster + firing-rate figure** (`.png`) per well.

---

## 2. What you need

- **MATLAB** R2021b or newer, with these toolboxes:
  - *Signal Processing Toolbox* (`findpeaks`),
  - *Statistics and Machine Learning Toolbox*,
  - *Curve Fitting Toolbox* (`smooth`).

No other downloads are required — every function is included in this folder.

---

## 3. What is in this folder

```
Tampere_NB_Toolbox/
├── run_tampere_pipeline.m      <-- THE ONLY FILE YOU RUN
├── README.md                   <-- this file
├── functions/                  <-- all the code (you don't touch these)
│   ├── filter_electrodes_by_FR.m      (step 2: firing-rate filter)
│   ├── DetectNetworkBurstsNeuro.m     (step 3: Tampere V1 detector)
│   ├── run_NBdetection_tampere.m      (step 3: runs the detector on all wells)
│   ├── get_tampere_params.m           (step 3: detector settings)
│   ├── export_NB_csv.m                (step 4: writes the CSV)
│   ├── plot_raster_firingrate.m       (step 4: draws the raster figure)
│   └── (helper functions: construct_ISIhist, BurstDetectISIn_MOD_AV,
│        MergeBurstsUniversal, CutBurstsUniversal, gaussian_kernel,
│        smooth_signal)
├── example_input/              <-- put your raw .mat file here
└── example_output/             <-- example of what the results look like
```

---

## 4. Input data format

You need **one raw spike file per cell line**, named after the cell line:
`DD1C.mat`, `DD5A.mat`, `TUBA.mat`, `C10902.mat`.

Inside `DD1C.mat` there is a single variable called `DD1C`, organised like this:

```
DD1C.(plate).(DIV).(well) = table with two columns:
      Time      spike times, in seconds
      Channel   electrode label
```

For example `DD1C.MEA1.DIV83.wellA1` is a table of spike times and electrodes
for one well. Recordings are 600 s, up to 16 electrodes per well.

Put the file in the `example_input/` folder (or anywhere, and point the script
to it — see below).

---

## 5. How to run

1. Open **`run_tampere_pipeline.m`** in MATLAB.
2. Edit the **SETTINGS** block at the top. The important ones:

   | Setting            | What it means                                            |
   |--------------------|----------------------------------------------------------|
   | `DATA_FILE`        | full path to your raw `.mat` file                        |
   | `RESULTS_ROOT`     | where results are saved (created automatically)          |
   | `PARAM_SET`        | detector settings, `1`–`4`. **Use `2` (recommended).**   |
   | `RASTER_WINDOW`    | time window shown in the figures, e.g. `[60 120]` seconds; use `[]` for the whole recording |
   | `MAX_WELLS_TO_PLOT`| how many wells to plot; `inf` = all                      |

3. Press the green **Run** button (or F5). That's it.

The script prints its progress (STEP 1 … STEP 4) and, at the end, tells you
exactly where the results were written.

---

## 6. Understanding the outputs

Everything is written under `RESULTS_ROOT` (default: a `results` folder next to
the script).

**Network bursts** — `results/network_bursts/`
- `NB_Tampere_<line>.mat` — results for MATLAB.
- `NB_Tampere_<line>.csv` — the same results as a spreadsheet. One row per
  network burst:

  | Column | Meaning |
  |--------|---------|
  | `CellLine`, `Plate`, `DIV`, `Well` | where the burst was found |
  | `NB_index` | burst number within the well (1, 2, 3, …) |
  | `Start_s`, `End_s`, `Duration_s` | timing of the burst, in seconds |
  | `Num_fragments` | number of sub-bursts inside the burst |
  | `Is_fragmented` | 1 if the burst has 2+ fragments, else 0 |
  | `Num_active_channels` | how many electrodes took part |

**Raster + firing-rate figures** — `results/raster_firingrate/<line>/<DIV>/`
- `<line>_<plate>_<DIV>_<well>_raster.png`. Each figure shows one well:
  - black **raster**: one row per electrode, one tick per spike;
  - blue **firing-rate** line on top (right axis, in Hz);
  - light-blue **shaded bands**: the detected network bursts;
  - magenta **dots**: fragment (sub-burst) peaks inside the bursts.

---

## 7. Changing the detector settings (optional)

All detector settings live in `functions/get_tampere_params.m`, grouped into
four "sets". **Set 2 is the reference** and is used by default; you normally do
not need to change anything. The most meaningful settings are:

- `MinCount` — minimum number of network bursts a well must have to be kept;
- `MinDuration` — minimum length of a network burst (seconds);
- `MinChannels` — minimum number of electrodes that must fire together;
- `sigma` / `kernelsize` — how strongly the firing-rate trace is smoothed.

---

## 8. Troubleshooting

- **"Data file not found"** — check the `DATA_FILE` path and that the `.mat`
  file is really in that folder.
- **"Undefined function ..."** — run the pipeline from inside the
  `Tampere_NB_Toolbox` folder; the script adds the `functions/` folder to the
  MATLAB path automatically.
- **Empty or few figures** — the firing-rate filter may have removed quiet
  wells, or no network bursts were found in that well. Try `RASTER_WINDOW = []`
  to see the whole recording.

---

## 9. Method reference

The Tampere V1 detector builds a pooled logarithmic ISI-N histogram, sets the
burst threshold at the first local minimum after the main peak, then applies
merging, minimum-duration, channel-count and channel-contribution criteria, and
finally a fragment (sub-burst) analysis. It is based on:

- Pasquale, Martinoia & Chiappalone (2010), *J. Comput. Neurosci.* 29:213–229.
- Bakkum et al. (2014), *Front. Comput. Neurosci.* 7:193.

From the MSc thesis *"Network burst detection and fragmentation analysis in
hiPSC-derived neuronal networks recorded on micro-electrode arrays"*
(J. Canestrelli, Tampere University).
