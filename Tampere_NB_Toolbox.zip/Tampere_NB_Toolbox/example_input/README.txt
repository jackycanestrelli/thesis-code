EXAMPLE INPUT
=============

Put ONE raw MEA spike file in this folder, for example:

    DD1C.mat        (or DD5A.mat, TUBA.mat, C10902.mat)

WHAT THE FILE MUST CONTAIN
--------------------------
Each raw file holds a SINGLE variable, named exactly like the file
(so DD1C.mat contains a variable called DD1C). That variable is a nested
structure organised like this:

    DD1C.(plate).(DIV).(well) = table with two columns:
          Time      spike times, in seconds
          Channel   electrode label (e.g. '12', '45', ...)

    Example path inside the file:
          DD1C.MEA1.DIV83.wellA1   ->   table(Time, Channel)

Recordings are 600 s long, with up to 16 electrodes per well.

HOW IT IS USED
--------------
The main script run_tampere_pipeline.m reads this file (see the DATA_FILE
setting at the top of that script), filters it, detects network bursts and
draws the raster figures.

NOTE
----
The real spike files are not shipped with this toolbox. Copy your own
DD1C.mat (or another cell line) into this folder before running.
